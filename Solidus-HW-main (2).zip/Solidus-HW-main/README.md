# Setup Instructions

Here are the steps to setup solidus app locally:

* Clone repo

* Create rvm gemset with ruby version 2.7.2

* Install rails 6.1.6

* Bundle it

* Create database

* Import backup.sql

* Run rails server
