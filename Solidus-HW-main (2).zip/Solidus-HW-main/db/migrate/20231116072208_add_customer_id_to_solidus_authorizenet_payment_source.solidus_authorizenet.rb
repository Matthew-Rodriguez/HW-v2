# This migration comes from solidus_authorizenet (originally 20220607202801)
class AddCustomerIdToSolidusAuthorizenetPaymentSource < ActiveRecord::Migration[6.1]
  def change
    add_column :solidus_authorizenet_payment_sources, :customer_id, :bigint
  end
end
