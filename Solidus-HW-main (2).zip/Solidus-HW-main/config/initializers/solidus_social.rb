# frozen_string_literal: true

Rails.application.config.to_prepare do
  Spree::SocialConfig.configure do |c|
    c.use_static_preferences!

    c.providers = {}

    begin
      c.providers[:bolt] = {
        api_key: SolidusBolt::BoltConfiguration.fetch.publishable_key,
        api_secret: SolidusBolt::BoltConfiguration.fetch.api_key,
      }
    rescue StandardError
    end
  end

  SolidusSocial.init_providers
end

OmniAuth.config.logger = Logger.new(STDOUT)
OmniAuth.logger.progname = 'omniauth'
OmniAuth.config.allowed_request_methods = [:get]


OmniAuth.config.on_failure = proc do |env|
  env['devise.mapping'] = Devise.mappings[Spree.user_class.table_name.singularize.to_sym]
  controller_klass = ActiveSupport::Inflector.constantize("Spree::OmniauthCallbacksController")
  controller_klass.action(:failure).call(env)
end
Rails.application.config.middleware.use OmniAuth::Builder do
  bolt_configuration = SolidusBolt::BoltConfiguration.fetch

  if bolt_configuration&.publishable_key.present? && bolt_configuration&.api_key.present?
    provider :bolt, publishable_key: bolt_configuration.publishable_key,
              api_key: bolt_configuration.api_key
  else
    Rails.logger.warn 'Bolt configuration missing'
  end
rescue StandardError
end
