# frozen_string_literal: true

# Warning: frontend is still part of the Solidus meta-gem. Make sure to enable
# these configurations only if they haven't been enabled in the `spree.rb`
# initializer.

# Spree.config do |config|
#   # Frontend:

#   Custom logo for the frontend
#   config.logo = "logo/solidus.svg"

#   Template to use when rendering layout
#   config.layout = "spree/layouts/spree_application"
# end

# Spree::Frontend::Config.configure do |config|
#   config.locale = 'en'
# end
